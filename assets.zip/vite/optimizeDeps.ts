export default {
  // include: optimizeDepsIncludes,
}
