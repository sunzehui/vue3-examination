export enum TagStatus {
  on,
  wait,
  off,
}
